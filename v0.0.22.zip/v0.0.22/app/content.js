/**
 * I. This addon inject iframe blocks into following LinkedIn pages:
 *      - Block 1: All LinkedIn pages
 *      - Block 2: LinkedIn user profiles
 *      - Block 3: Sales navigator
 *      - Block 4: Display on Messenger page
 *
 * II. When following conditions are met, the opened profile is automatically parsed and saved on the server:
 *      - A LinkedIn profile page is opened
 *      - It contains a cid argument (candidate's ID)
 */

// const http = require("http");
const MODE_PRODUCTION = true;

const serverUrl = MODE_PRODUCTION ? 'https://g7.myshortlist.co' : 'http://localhost:7777';
const iframesUrl = MODE_PRODUCTION ? 'https://kass.myshortlist.co' : 'http://localhost:3000';

/**
 * ----------------------------------------------------
 * Helper 1: A function to scroll down
 */
const scrollTo = (window, to, duration) => new Promise((resolve, reject) => {
    let timeSmooth = 25
    let deltaTime = duration / timeSmooth
    let deltaPosition = to / deltaTime;
    let position = 0
    const timer = setInterval(function () {
        window.scrollBy(0, position);
        position += deltaPosition;
        if (position >= to) {
            clearInterval(timer);
            resolve(true)
        }
    }, deltaTime);
});

/**
 * ----------------------------------------------------
 * Helper 2: A function to make a pause
 */
const pauseKF = (delay = 0) => new Promise((resolve, reject) => {
    setTimeout(() => resolve(true), 1000 + delay);
});

/**
 * ----------------------------------------------------
 * Helper 3: A function to extract user token for profile url
 */
function extractProfileToken(url) {
    if (!url) return '###';
    const bag = url.split('/');
    for (let i = 0; i < bag.length; i++) {
        if (bag[i] === 'in') {
            return bag[i + 1]
        }
    }
    return '###';
}

// function parseCookies (request) {
//     const list = {};
//     const cookieHeader = request.headers?.cookie;
//     if (!cookieHeader) return list;
//
//     cookieHeader.split(`;`).forEach(function(cookie) {
//         let [ name, ...rest] = cookie.split(`=`);
//         name = name?.trim();
//         if (!name) return;
//         const value = rest.join(`=`).trim();
//         if (!value) return;
//         list[name] = decodeURIComponent(value);
//     });
//
//     return list;
// }

function main() {

    /**
     * Detect current page
     */
    let isCurrentPageUserProfile = window.location.href.includes('/in/');
    let isCurrentPageMessenger = window.location.href.includes('/messaging/');
    let isCurrentPageOnLinkedin = window.location.href.includes('linkedin.com');
    let doesCurrentPageHasCid = window.location.href.includes('cid=');

    /**
     * Detect if blocs are displayed
     */
    let isBlockInDisplayed = !!document.getElementById('shadow-in'); // Block de gauche
    let isBlockProfileDisplayed = !!document.getElementById('shadow-in-profile');
    let isBlockMessengerDisplayed = !!document.getElementById('shadow-in-messenger');

    /**
     * ----------------------------------------------------
     * I. Block 1. Display on all LinkedIn pages
     */
    (async () => {
        if (isCurrentPageOnLinkedin && !isBlockInDisplayed) {
            function toggleInPanel() {
                const bbWindow = document.getElementById('shadow-in');
                const bbWindowBtn = document.getElementById('shadow-in-button');
                if (bbWindow.classList.contains('hide-block')) {
                    bbWindow.classList.remove('hide-block');
                    bbWindowBtn.classList.add('hide-block');
                } else {
                    bbWindowBtn.classList.remove('hide-block');
                    bbWindow.classList.add('hide-block');
                }
            }

            function displayInBlock() {
                let newBlock = document.createElement('section');
                newBlock.id = "shadow-in";
                newBlock.className = 'hide-block';
                newBlock.innerHTML = '<button id="shadow-in__close">Fermer</button>' +
                    '<article class="in-messages">' +
                    '<div class="in-messages__message">Bienvenue dans l\'extension Black-belt. Celle ci ajoute un bon nombre de fonctionnalités à LinkedIn:' +
                    ' Parse les profils depuis Myshortlist,' +
                    'Ajoute un bloc BB aux profils LinkedIn,' +
                    'Ajoute un bloc BB a la messagerie LinkedIn.' +
                    '</div>' +
                    '</article>';
                document.body.appendChild(newBlock);
                document.getElementById('shadow-in__close').addEventListener('click', () => toggleInPanel())
            }

            function displayInButton() {
                /**
                 * Helper to toggle window
                 */
                let newBlock = document.createElement('div');
                newBlock.id = "shadow-in-button";
                newBlock.innerHTML = '<button>' +
                    'BB' +
                    '</button>';
                document.body.appendChild(newBlock);
                document.getElementById('shadow-in-button').addEventListener('click', () => toggleInPanel())
            }

            displayInBlock();
            displayInButton();
        }
    })();

    /**
     * ----------------------------------------------------
     * I. Block 2. Display on all LinkedIn profiles
     */
    (async () => {
        if (isCurrentPageUserProfile && !doesCurrentPageHasCid && isBlockProfileDisplayed) {
            // Push user token
            if (document.getElementById('shadow-in-profile-iframe')) {
                document.getElementById('shadow-in-profile-iframe').contentWindow.postMessage({
                    type: 'setProfileToken',
                    data: {
                        linkedinToken: extractProfileToken(window.location.href),
                        linkedin: window.location.href.split('?')[0].split('#')[0]
                    }
                }, '*');
            }
        }
        if (isCurrentPageUserProfile && !doesCurrentPageHasCid && !isBlockProfileDisplayed) {
            async function displayInProfileBlock() {
                let newBlock = document.createElement('section');
                newBlock.id = "shadow-in-profile";
                newBlock.innerHTML = `<iframe id="shadow-in-profile-iframe" src="${iframesUrl}/profileBlock" width="720px" height="290px"></iframe>`;
                document.getElementsByClassName('ph5')[0].appendChild(newBlock);
                await pauseKF(200);
                // Push user token
                document.getElementById('shadow-in-profile-iframe').contentWindow.postMessage({
                    type: 'setProfileToken',
                    data: {
                        linkedinToken: extractProfileToken(window.location.href),
                        linkedin: window.location.href.split('?')[0].split('#')[0]
                    }
                }, '*');
            }

            displayInProfileBlock();
        }
    })();

    /**
     * ----------------------------------------------------
     * I. Block 3. Display on Messenger page
     */
    (async () => {
        if (isCurrentPageMessenger && !isBlockMessengerDisplayed) {
            function displayInProfileBlock() {
                let newBlock = document.createElement('section');

                newBlock.id = "shadow-in-messenger";

                newBlock.innerHTML = `<iframe id="shadow-in-messenger-iframe" src="${iframesUrl}/messengerBlock" width="290px" height=400px"></iframe>`;

                let layoutAside = (document.getElementsByClassName('scaffold-layout__aside')[0] ?? {});

                // Fallback for new layout
                if (!layoutAside) {
                    (document.getElementsByClassName('ad-banner-container')[0] ?? {})
                }

                if (!layoutAside) {
                    alert("Impossible de trouver le bloc de droite");
                }

                layoutAside.insertBefore(newBlock, layoutAside.firstChild);
            }

            setTimeout(() => displayInProfileBlock(), 500);
        }
    })();

    /**
     * ----------------------------------------------------
     * II. Parse the page if it is a profile and url contains cid
     */
    // Deprecated because of AutomatedParser since it has the same behavior
    // (async () => {
    //     if (isCurrentPageUserProfile && doesCurrentPageHasCid) {
    //
    //         const cid = ((window.location.href.split('cid=')[1] ?? "").split('&')[0] ?? "").split('#')[0] ?? "";
    //         const mid = ((window.location.href.split('mid=')[1] ?? "").split('&')[0] ?? "").split('#')[0] ?? "";
    //
    //         function addBlackScreenAndTimer() {
    //             // States of the timer: timer, error, success
    //             let shadowContainer = document.createElement('section');
    //             shadowContainer.id = "shadow-container";
    //             shadowContainer.innerHTML = '<article id="shadow-container__label">' +
    //                 'ATTENTE...' +
    //                 '</article>';
    //             document.body.appendChild(shadowContainer);
    //         }
    //
    //         function setTimerSuccess() {
    //             document.getElementById('shadow-container__label').innerText = 'Ok';
    //         }
    //
    //         function setTimerError() {
    //             document.getElementById('shadow-container__label').innerText = 'Error';
    //         }
    //
    //         async function expandAllButtonsOnProfile() {
    //             try {
    //                 await scrollTo(window, 900, 800);
    //
    //                 // See more buttons
    //                 const seeMoreExt = document.getElementsByClassName('inline-show-more-text__button');
    //                 if (seeMoreExt && seeMoreExt.length !== 0) {
    //                     for (let button of seeMoreExt) {
    //                         button.click()
    //                         await pauseKF(-200)
    //                     }
    //                 }
    //
    //                 // Profiles buttons
    //                 const profileExt = document.getElementsByClassName('pv-profile-section__see-more-inline');
    //                 if (profileExt && profileExt.length !== 0) {
    //                     for (let button of profileExt) {
    //                         button.click()
    //                         await pauseKF(-200)
    //                     }
    //                 }
    //
    //                 // Skills
    //                 const skillsExt = document.getElementsByClassName('pv-skills-section__additional-skills');
    //                 if (skillsExt && skillsExt.length !== 0) {
    //                     skillsExt[0].click();
    //                 }
    //             } catch (error) {
    //                 console.error(error.message);
    //             }
    //         }
    //
    //         function parsePageToString() {
    //             return document.documentElement?.innerHTML?.toString() ?? '';
    //         }
    //
    //         async function clickContactOnProfile() {
    //             try {
    //                 const contactButtons = document.getElementsByClassName('link-without-visited-state cursor-pointer');
    //                 contactButtons[0].click()
    //                 return 'success';
    //             } catch (error) {
    //                 console.error(error.message);
    //                 return 'error';
    //             }
    //         }
    //
    //         async function sendParsedProfileWithCid(args) {
    //             try {
    //
    //                 const rawAnswer = await fetch(`${serverUrl}/v3/communities/parse/in/profile`, {
    //                     method: 'PUT',
    //                     body: JSON.stringify({
    //                         cid: args.cid,
    //                         mid: args.mid,
    //                         pageProfile: args.pageProfile,
    //                         pageContact: args.pageContact
    //                     }),
    //                     headers: new Headers({
    //                         'Content-Type': 'application/json'
    //                     })
    //                 });
    //
    //                 const answer = await rawAnswer.json();
    //
    //                 if (answer.status !== 'ok') {
    //                     throw new Error(answer.status ?? 'Not defined')
    //                 }
    //
    //                 setTimerSuccess();
    //
    //             } catch (error) {
    //                 setTimerError();
    //                 console.error(error);
    //             }
    //         }
    //
    //         addBlackScreenAndTimer();
    //
    //         await expandAllButtonsOnProfile();
    //
    //         let pageProfile = parsePageToString();
    //         let pageContact = '';
    //
    //         const clickedContact = await clickContactOnProfile();
    //
    //         if (clickedContact === 'success') {
    //             pageContact = parsePageToString();
    //         }
    //
    //         await sendParsedProfileWithCid({pageProfile, pageContact, cid, mid});
    //     }
    // })();

    /**
     * Parse the page and send it to the server
     */
    class AutomatedParser {
        constructor() {
            const visitedStr = localStorage.getItem("bb_visited") || "[]";
            const visited = JSON.parse(visitedStr)
            if (visited.length >= 300) {
                localStorage.removeItem("bb_visited")
            }
        }

        isPageVisited() {
            const visitedStr = localStorage.getItem("bb_visited") || "[]";
            const visited = JSON.parse(visitedStr)
            return !!visited.includes(window.location.href);
        }

        markPageAsVisited() {
            const visitedStr = localStorage.getItem("bb_visited") || "[]";
            const visited = JSON.parse(visitedStr)
            visited.push(window.location.href)
            localStorage.setItem("bb_visited", JSON.stringify(visited))
        }

        showNotification(error, message) {
            const newDiv = document.createElement("div");
            newDiv.style.position = "absolute";
            newDiv.style.top = "15px";
            newDiv.style.left = "15px";
            newDiv.style.padding = "8px 15px";
            newDiv.style.width = "200px";
            newDiv.style.fontSize = "12px";
            newDiv.style.backgroundColor = error ? "#bf3528" : "#000000";
            newDiv.style.color = "white";
            newDiv.style.zIndex = "100000000"; // To ensure it's above other elements
            newDiv.innerHTML = "BB - " + message;
            document.body.appendChild(newDiv);
            setTimeout(function () {
                newDiv.remove();
            }, 1500)
        }

        async parsePageAndSend() {
            try {
                // if there is a candidate id, take it
                const cid = ((window.location.href.split('cid=')[1] ?? "").split('&')[0] ?? "").split('#')[0] ?? "";
                const mid = ((window.location.href.split('mid=')[1] ?? "").split('&')[0] ?? "").split('#')[0] ?? "";

                const rawAnswer = await fetch(`${serverUrl}/v3/communities/parse/in/profile/auto`, {
                    method: 'POST',
                    body: JSON.stringify({
                        cid: cid,
                        mid: mid,
                        pageProfile: document.documentElement?.innerHTML?.toString() ?? ''
                    }),
                    headers: new Headers({
                        'Content-Type': 'application/json'
                    })
                });

                const answer = await rawAnswer.json();

                if (answer.status === 'ok') {
                    this.showNotification(false, "Parsé avec succès")
                } else if (answer.status === 'already-parsed') {
                    this.showNotification(false, "Déjà parsé")
                } else if (answer.status === 'error') {
                    this.showNotification(true, "Erreur P2 lors du parsing")
                } else {
                    throw new Error("Got wrong status")
                }
            } catch (error) {
                console.error(error);
                this.showNotification(true, "Erreur P1 lors du parsing")
            }
        }

        start() {
            setInterval(async () => {
                try {
                    if (!window.location.href.includes('/in/')) {
                        return;
                    }
                    if (this.isPageVisited()) {
                        return;
                    }
                    this.markPageAsVisited();
                    this.parsePageAndSend();
                } catch (e) {
                    console.error(e);
                }
            }, 1000)
        }
    }

    const automatedParser = new AutomatedParser();
    automatedParser.start();
}

/**
 * ========================================================================================================
 * Functions for cross-document messaging
 */
window.onmessage = function (e) {

    if (e.data && e.data.type) {

        switch (e.data.type) {

            case 'getFullProfile':
                const profile = document.documentElement?.innerHTML?.toString() ?? ''; // todo, appuyer sur les bouttons avant
                const profileContact = ''; // todo: ajouter le parsing de la fiche contact
                if (document.getElementById('shadow-in-profile-iframe')) {

                    document.getElementById('shadow-in-profile-iframe').contentWindow.postMessage({
                        type: 'getFullProfileCB', data: {
                            profile: profile,
                            profileContact: profileContact,
                        }
                    }, '*');
                }
                break;

            case 'parseOneMessage': {
                (async () => {
                    const page = document.documentElement?.innerHTML?.toString() ?? '';
                    const profile = document.getElementsByClassName('msg-title-bar__title-bar-title') ?? [];
                    console.log("profile", profile);
                    (profile[0].querySelector('a') ?? {}).click();
                    await pauseKF(1550);
                    const coordinateButton = document.getElementsByClassName('pb2')[0].getElementsByClassName('link-without-visited-state')[0];
                    coordinateButton.click();
                    await pauseKF(700);
                    const coordinates = document.documentElement?.innerHTML?.toString() ?? '';
                    await pauseKF(700);
                    (document.getElementsByClassName('artdeco-modal__dismiss')[0] ?? {}).click();
                    const messenger = document.getElementsByClassName('global-nav__primary-item') ?? [];
                    console.log("messenger", messenger);
                    (messenger[3].querySelector('a') ?? {}).click();
                    await pauseKF(700);
                    if (document.getElementById('shadow-in-messenger-iframe')) {
                        document.getElementById('shadow-in-messenger-iframe').contentWindow.postMessage({
                            type: 'parseMessageCB',
                            data: {
                                page: page,
                                coordinates: coordinates,
                            }
                        }, '*');
                        alert("Fin de l'import (1)");
                    }
                })();
                break;
            }

            case 'parseAllMessages': {
                (async () => {
                    const allDiscussions = document.getElementsByClassName('scaffold-layout__list-item') ?? [];

                    if (!allDiscussions || !allDiscussions.length) {
                        alert("Aucune discussion trouvée");
                    }

                    for (let discussion of allDiscussions) {
                        const messageLink = discussion.querySelector('a')

                        if (!messageLink) {
                            alert("Impossible de trouver le lien de la discussion");
                            continue;
                        }

                        messageLink.click();

                        await pauseKF(1750);

                        const message = document.getElementById('shadow-in-messenger-iframe')

                        if (!message) {
                            alert("Impossible de trouver le message");
                            continue;
                        }

                        document.getElementById('shadow-in-messenger-iframe').contentWindow.postMessage({
                            type: 'parseMessageCB',
                            data: {
                                page: document.documentElement?.innerHTML?.toString() ?? ''
                            }
                        }, '*');

                        await pauseKF(800);
                    }

                    alert("Fin de l'import " + "(" + allDiscussions.length + ")");
                })();
            }
                break;

            case 'getProfileCoordinates': {
                (async () => {
                    // div pb2 et un a link-without-visited-state
                    const coordinateButton = document.getElementsByClassName('pb2')[0].getElementsByClassName('link-without-visited-state')[0];

                    // 1. Clicker sur le bouton
                    coordinateButton.click();

                    await pauseKF(700);

                    // 2. Récupérer le code de la page sous forme de string
                    const page = document.documentElement?.innerHTML?.toString() ?? '';

                    // 3. Fermer la fenêtre
                    (document.getElementsByClassName('artdeco-modal__dismiss')[0] ?? {}).click();

                    // 3. Envoyer ce code dans l'iframe
                    if (document.getElementById('shadow-in-profile-iframe')) {
                        document.getElementById('shadow-in-profile-iframe').contentWindow.postMessage({
                            type: 'updateCoordinates',
                            data: {
                                page: page
                            }
                        }, '*');
                    }
                })();
            }
                break;

            case 'writeMessage': {
                (async () => {
                        //recuperer le prenom
                        let firstName = "";
                        const header = (document.getElementsByClassName('msg-entity-lockup__entity-title-wrapper') ?? [])[0];
                        if (header) {
                            const fullName = ((header.getElementsByTagName('h2') ?? [])[0] ?? {}).innerText ?? "";
                            firstName = (fullName ?? "").split(' ')[0];
                        }

                        let discussion = (document.getElementsByClassName('msg-s-event-listitem__body') ?? []);
                        let discussionText = [];
                        let ref;

                        for (let item of discussion) {
                            discussionText.push(item.innerText ?? "");
                        }
                        console.log(discussionText);

                        for (let item of discussionText) {
                            if (item.includes('ref#')) {
                                let bag = item.split(' ');
                                for (let word of bag) {
                                    if (word.includes('ref#')) {
                                        ref = ((word.split('ref#') ?? [])[1]).replace(')', '');
                                    }
                                }
                            }
                        }

                        console.log(ref);


                        //injecter le contenu
                        const link = `https://black-belt.typeform.com/coopt#missionref=${ref}`
                        if (e.data?.data?.message === "cooptation") {
                            (document.getElementsByClassName('msg-form__contenteditable')[0] ?? {}).innerHTML =
                                `<p class="app-aware-link"> C'est noté, merci à vous! Pouvez-vous me recommander un candidat? 
                                     Si oui, cooptez le via ce lien et gagnez 500€ s'il est embauché!
                                     <span id="link" > https://app.black-belt.io/coopt/${ref}</span>
                                </p>`;
                            (document.getElementById('link') ?? {}).href = link;
                            (document.getElementById('link') ?? {}).target = "_blank";

                        } else {
                            (document.getElementsByClassName('msg-form__contenteditable')[0] ?? {}).innerHTML = `<p>${(e.data?.data?.message ?? "").replace('{{firstName}}', firstName).replace('{{ref}}', ref)}</p>`;
                        }
                        //cacher le placeHolder
                        const placeHolder = (document.getElementsByClassName('msg-form__placeholder') ?? [])[0];
                        if (!!placeHolder) {
                            placeHolder.classList.add('hidden');
                            //enlever le disabled
                            let sendButton = (document.getElementsByClassName("msg-form__send-button"))[0] ?? {};
                            //sendButton.removeAttribute("disabled");
                            sendButton.disabled = false;
                        }
                    }
                )()
            }

        }
    }

};


/**
 * Launch code when page loaded
 */
setTimeout(() => main(), 1200);

/**
 * Relaunch code when a user clicks anywhere (did this because of linkedin being a single page app, otherwise it's only loaded once)
 * NB: very not efficient in terms of memory
 */
((document.getElementsByTagName('body') ?? [])[0] ?? {}).addEventListener('click', () => {
    setTimeout(() => main(), 1200);
});
